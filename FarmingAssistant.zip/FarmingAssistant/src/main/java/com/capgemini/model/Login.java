package com.capgemini.model;
//package com.cap.entities;
//
//public class Login {
//	
//	private String userName;
//	private String password;
//	private String flag;
//	
//	
//	public Login(String userName, String password, String flag) {
//		super();
//		this.userName = userName;
//		this.password = password;
//		this.flag = flag;
//	}
//
//
//	public Login() {
//		super();
//	}
//
//
//	public String getUserName() {
//		return userName;
//	}
//
//
//	public void setUserName(String userName) {
//		this.userName = userName;
//	}
//
//
//	public String getPassword() {
//		return password;
//	}
//
//
//	public void setPassword(String password) {
//		this.password = password;
//	}
//
//
//	public String getFlag() {
//		return flag;
//	}
//
//
//	public void setFlag(String flag) {
//		this.flag = flag;
//	}
//	
//	
//	
//}
