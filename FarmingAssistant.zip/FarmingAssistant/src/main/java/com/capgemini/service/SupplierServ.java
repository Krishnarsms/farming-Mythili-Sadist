package com.capgemini.service;

import org.springframework.stereotype.Service;

import com.capgemini.model.Supplier;

@Service
public interface SupplierServ {
	
	//Supplier Registration
	public Supplier supplierRegistration(Supplier supplierReg);
	
	//Supplier Login
	public Supplier loginBySupplierEmail(String supplier_Email,String supplier_Password);

}
