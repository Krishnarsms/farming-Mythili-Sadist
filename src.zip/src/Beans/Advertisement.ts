export class Advertisement{
crop_Id:number;
crop_Name:String;
crop_Image:ImageBitmap;
crop_Qty:String;


constructor(crop_Id:number,crop_Name:String,crop_Image:ImageBitmap,crop_Qty:String){
    this.crop_Id=crop_Id;
    this.crop_Name=crop_Name;
    this.crop_Image=crop_Image;
    this.crop_Qty=crop_Qty;
}
}