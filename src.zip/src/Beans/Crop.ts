export class Crop{

    crop_Id: number;
    crop_Name: string;
    crop_Details: string;
    crop_Price: string;
    crop_Qty:string;
    farmer_Id:number;
    supplier_Id:number;
    flag: string;
    
    

    constructor(
        crop_Id: number,
        crop_Name: string,
        crop_Details: string,
        crop_Price: string,
        crop_Qty:string,
        farmer_Id:number,
        supplier_Id:number,
        flag: string
        )
    {
        this.crop_Id = crop_Id;
        this.crop_Name = crop_Name;
        this.crop_Details = crop_Details;
        this.crop_Price=crop_Price;
        this.crop_Qty=crop_Qty;
        this.farmer_Id = farmer_Id;
        this.supplier_Id = supplier_Id;
        this.flag = flag;
        
    }

}