export class Supplier{
    supplier_Id:number;
    supplier_Name:String;
    supplier_Address:String;
    supplier_MobileNumber:String;
    supplier_Email:String;
    supplier_Password:String;


constructor(supplier_Id:number,supplier_Name:String,supplier_Address:String,supplier_MobileNumber:String,
    supplier_Email:String,supplier_Password:String){
        this.supplier_Id=supplier_Id;
        this.supplier_Name=supplier_Name;
        this.supplier_Address=supplier_Address;
        this.supplier_MobileNumber=supplier_MobileNumber;
        this.supplier_Email=supplier_Email;
        this. supplier_Password=supplier_Password;
    }
}