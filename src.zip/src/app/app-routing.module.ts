import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FarmerLoginComponent } from './farmer-login/farmer-login.component';
import { AppComponent } from './app.component';
import { FarmerRegisterComponent } from './farmer-register/farmer-register.component';
import { FarmeHomeComponent } from './farme-home/farme-home.component';
import { ViewProductRequirementComponent } from './view-product-requirement/view-product-requirement.component';
import { ViewUsersComponent } from './view-users/view-users.component';
import { SupplierHomeComponent } from './supplier-home/supplier-home.component';
import { SupplierLoginComponent } from './supplier-login/supplier-login.component';
import { SupplierRegisterComponent } from './supplier-register/supplier-register.component';
import { PostAddComponent } from './post-add/post-add.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { HomePageComponent } from './home-page/home-page.component';


const routes: Routes = [

  
  
  {
    path:"homePage",
    component: HomePageComponent
    },

  {
    path:"farmerLogin",
    component: FarmerLoginComponent
  },

  {path:"forgotPassword",
   component:ForgotPasswordComponent
  },
  {
    path:"farmerRegister",
    component: FarmerRegisterComponent
  },
  {
    path:"farmerHome",
    component: FarmeHomeComponent
  },
  {
    path:"productRequirements",
    component: ViewProductRequirementComponent
  },
  {
    path:"viewUsers",
    component: ViewUsersComponent
  },
  {
    path:"supplierHome",
    component:SupplierHomeComponent
  },
  {
    path:"supplierLogin",
    component:SupplierLoginComponent
  },
  {
    path:"supplierRegister",
    component:SupplierRegisterComponent
  },
  {
    path:"addAdvertisement",
    component:PostAddComponent
  }
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
