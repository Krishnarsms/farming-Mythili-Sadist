import { Component, OnInit } from '@angular/core';
import { Advertisement } from 'src/Beans/Advertisement';
import { FarmerServiceService } from '../farmer-service.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-post-add',
  templateUrl: './post-add.component.html',
  styleUrls: ['./post-add.component.css']
})
export class PostAddComponent implements OnInit {

  postAdd:Advertisement;
  farmerServ:FarmerServiceService;
  router:Router;
  httpClient:HttpClient;
  selectedFile:File;
  constructor(farmerServ:FarmerServiceService,router:Router,httpClient:HttpClient) {
    this.farmerServ=farmerServ;
    this.router=router;
    this.httpClient=httpClient;
   }


  ngOnInit() {
  }

  public onFileChanged(event){
    this.selectedFile=event.target.files[0];
  }

  onUpload(){
    console.log(this.selectedFile);
    const uploadImageData=new FormData();
    uploadImageData.append('imageFile',this.selectedFile,this.selectedFile.name);
  }

  postaddform(data:any){
    let postAdd=new Advertisement(data.crop_Id,data.crop_Name,data.crop_Image,data.crop_Qty)
    this.farmerServ.addPost(postAdd).then(response=>{
      this.router.navigateByUrl('supplierHome');
      },
      err=>{
        if (err.success != undefined && err.success == false) {
          alert(err.errors);
          }
      });
    }

}
